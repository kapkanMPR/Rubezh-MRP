using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using Rubezh;
using Rubezh.Camp;
using Rubezh.UnityPort;
using SilentOrders.Core;
using UnityEngine;
using UnityEngine.UIElements;

class Lifetime122Check
{
    static int checks;
    static BindingFlags F = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    static List<string> loads = new List<string>();
    static HashSet<UnityEngine.Object> unloaded = new HashSet<UnityEngine.Object>();
    static Dictionary<string, UnityEngine.Object> objects = new Dictionary<string, UnityEngine.Object>();

    static object Call(object x, string method, params object[] a)
    {
        try
        {
            return x.GetType().GetMethod(method, F).Invoke(x, a);
        }
        catch (TargetInvocationException e)
        {
            throw e.InnerException;
        }
    }

    static void Set(object x, string field, object value) => x.GetType().GetField(field, F).SetValue(x, value);

    static T Get<T>(object x, string field) => (T)x.GetType().GetField(field, F).GetValue(x);

    static void Check(bool yes, string text)
    {
        if (!yes)
            throw new Exception(text);
        checks++;
        Console.WriteLine("PASS " + text);
    }

    static UnityEngine.Object Load(string p)
    {
        loads.Add(p);
        if (objects.ContainsKey(p))
            return objects[p];
        UnityEngine.Object obj = null;
        string path = "Assets/Rubezh/Resources/" + p;
        if (p.StartsWith("Audio/") || p.StartsWith("Music/"))
            obj = AudioClip.Create(p, 100, 1, 22050, false);
        else if (p == "FieldCamp/Camp")
            obj = new StyleSheet();
        else if (p == "FieldCamp/CampTheme")
            obj = new ThemeStyleSheet();
        else if (p.Contains("Fonts/"))
            obj = new Font();
        else if (File.Exists(path + ".png"))
            obj = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        else if (File.Exists(path + ".json"))
            obj = new TextAsset { text = File.ReadAllText(path + ".json") };
        else if (p.StartsWith("Levels/Campaign_"))
            obj = JsonConvert
                .DeserializeObject<BuiltinCampaign.Map>(
                    File.ReadAllText("Validation/Current/maps/" + p.Substring(7) + ".json")
                )
                .Create();
        objects[p] = obj;
        return obj;
    }

    static void Main()
    {
        Resources.Loader = Load;
        Resources.OnUnload = o =>
        {
            unloaded.Add(o);
            foreach (var key in objects.Where(x => ReferenceEquals(x.Value, o)).Select(x => x.Key).ToArray())
                objects.Remove(key);
        };
        var app = new RubezhApp();
        Call(app, "InitOptions");
        Check(!loads.Any(x => x.StartsWith("Audio/")), "camp initialization does not preload battle audio");
        Call(app, "LoadBattleSamples");
        var samples = objects.Where(x => x.Key.StartsWith("Audio/")).Select(x => x.Value).ToArray();
        Check(samples.Length == 13, "battle requests 13 sound samples");
        int requests = loads.Count;
        Call(app, "LoadBattleSamples");
        Check(loads.Count == requests, "battle audio load idempotent");
        Call(app, "ReleaseBattleSamples");
        Check(
            samples.All(x => unloaded.Contains(x)) && Get<AudioClip[]>(app, "weaponSounds") == null,
            "all combat audio released"
        );
        Set(app, "soundEnabled", false);
        requests = loads.Count;
        Call(app, "LoadBattleSamples");
        Check(loads.Count == requests, "disabled sounds stay unloaded");
        var b = new BattleSimulation(122);
        Check(RubezhLevelRuntime.Apply(b, true, 1), "apply real serialized map");
        Check(!objects.ContainsKey("Levels/Campaign_01"), "serialized level resource released after map copy");
        for (int i = 0; i < 10; i++)
            b.Step();
        Check(b.Map.CustomLevel, "map remains usable after release");
        var cached = BuiltinCampaign.Find(1);
        Check(BuiltinCampaign.Owns(cached), "baseline cache ownership");
        Check(!objects.ContainsKey("CampaignBaseline"), "baseline JSON released after parse");
        var cat = JsonConvert.DeserializeObject<Catalog>(
            File.ReadAllText("Assets/Rubezh/Resources/FieldCamp/catalog.json")
        );
        var model = new CampModel(cat);
        var store = new CampStore(Path.Combine(Path.GetTempPath(), "rubezh122-lifetime.json"), model);
        var view = new NativeCampView();
        view.Initialize(store, true);
        Set(app, "nativeCamp", view);
        Set(app, "campStore", store);
        Set(app, "battle", b);
        Set(app, "screen", 2);
        Set(app, "sceneArtBattle", b);
        Set(app, "soundEnabled", true);
        Call(app, "LoadBattleSamples");
        Rubezh.Graphics.ConfigurePacks();
        foreach (var page in Rubezh.Graphics.CommonPages())
            Rubezh.Graphics.LoadPage(
                page,
                File.ReadAllBytes("Assets/Rubezh/Editor/LegacySources/" + SpritePackIndex.Path(page) + ".bytes")
            );
        Check(Rubezh.Graphics.LoadedPixelBytes > 0, "battle graphics resident before exit");
        Call(app, "ShowCamp");
        Check(
            Rubezh.Graphics.LoadedPixelBytes == 0 && Get<object>(app, "sceneArtBattle") == null,
            "return to camp immediately frees battle graphics"
        );
        Check(Get<AudioClip[]>(app, "weaponSounds") == null, "return to camp frees audio");
        Check(!BuiltinCampaign.Owns(cached), "return to camp drops baseline snapshots");
        var old = AudioClip.Create("old", 100, 1, 22050, false);
        Get<AudioSource>(app, "musicB").clip = old;
        Set(app, "musicBlend", 1f);
        Set(app, "musicEnabled", false);
        Call(app, "UpdateAudio");
        Check(
            unloaded.Contains(old) && Get<AudioSource>(app, "musicB").clip == null,
            "finished crossfade frees previous music"
        );
        Call(view, "OnDestroy");
        Console.WriteLine("PASS lifecycle checks=" + checks + " (contract calls, not native allocator measurements)");
    }
}
