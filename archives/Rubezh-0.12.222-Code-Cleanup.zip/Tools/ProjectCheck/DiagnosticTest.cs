using System;
using System.Reflection;
using Rubezh.UnityPort;
using UnityEngine;

class DiagnosticTest
{
    static void Main()
    {
        var a = new RubezhApp();
        typeof(RubezhApp).GetField("campaignMode", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(a, false);
        var kits = (Kit[])
            typeof(RubezhApp).GetProperty("Kits", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(a);
        if (kits == null || kits.Length != 5)
            throw new Exception("Quick kits missing");
        var u = typeof(RubezhApp).GetMethod("UpdateDiagnostics", BindingFlags.NonPublic | BindingFlags.Instance);
        var c = typeof(RubezhApp).GetMethod("CapturePerformance", BindingFlags.NonPublic | BindingFlags.Instance);
        Time.unscaledDeltaTime = .02f;
        for (int i = 0; i < 5000; i++)
        {
            Time.realtimeSinceStartup = i;
            u.Invoke(a, null);
        }
        var r = (PerformanceReport)c.Invoke(a, null);
        if (
            r.frameCount != 3600
            || r.history.Length != 180
            || Math.Abs(r.frameP95 - 20) > .01
            || Math.Abs(r.fps - 50) > .01
            || r.over100ms != 0
        )
            throw new Exception("Invalid telemetry");
        Time.unscaledDeltaTime = .2f;
        u.Invoke(a, null);
        r = (PerformanceReport)c.Invoke(a, null);
        if (r.over100ms != 1 || r.frameMax < 199)
            throw new Exception("Lost slow frame");
        var record = typeof(RubezhApp).GetMethod("RecordOperation", BindingFlags.NonPublic | BindingFlags.Instance);
        for (int i = 0; i < 100; i++)
            record.Invoke(a, new object[] { "simulation", 100f, GC.CollectionCount(0) });
        r = (PerformanceReport)c.Invoke(a, null);
        if (r.schema != 12 || r.slowOperations.Length != 64 || r.slowOperations[0].ms != 100)
            throw new Exception("Lost raw spikes");
        if (r.current.gpuFrameMs != -1 || r.current.cpuFrameMs != -1)
            throw new Exception("Unavailable native timing must be explicit");
        Console.WriteLine(
            "PASS bounded diagnostics: 3600 frames, 180 memory samples; percentiles, FPS and slow-frame counts; report export capture"
        );
    }
}
