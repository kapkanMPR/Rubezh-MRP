using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Rubezh.UnityPort;
using SilentOrders.Core;

class Test
{
    static readonly List<object> results = new List<object>();

    static void Log(object value)
    {
        results.Add(value);
        Console.WriteLine(JsonConvert.SerializeObject(value));
        Console.Out.Flush();
    }

    static BattleSimulation Load(int seed = 151)
    {
        var b = new BattleSimulation(seed);
        CampaignScenario.Apply(b, "1,19,0,0,0,0");
        var level = JsonConvert
            .DeserializeObject<BuiltinCampaign.Map>(
                File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "level01-geometry.json"))
            )
            .Create();
        if (!RubezhLevelRuntime.ApplyLevel(b, level))
            throw new Exception(RubezhLevelRuntime.LastError);
        return b;
    }

    static int Solid(BattleSimulation b)
    {
        int n = 0;
        foreach (var h in b.Map.DynamicBuildings)
        foreach (var w in h.Walls)
        foreach (bool v in w.Solid)
            if (v)
                n++;
        return n;
    }

    static int Tall(BattleSimulation b)
    {
        int n = 0;
        foreach (var h in b.Map.DynamicBuildings)
        foreach (var w in h.Walls)
            for (int z = 0; z < w.NZ; z++)
                if ((z + .5f) * w.Source.height / w.NZ > .9f)
                    for (int x = 0; x < w.NX; x++)
                        if (w.Solid[z * w.NX + x])
                            n++;
        return n;
    }

    static int Roof(BattleSimulation b) => b.Map.DynamicBuildings.Sum(h => h.Roof.Count);

    static int Glass(BattleSimulation b) =>
        b.Map.DynamicBuildings.Sum(h => h.Walls.Count(w => w.Source.window && w.GlassBroken));

    static DynamicBuilding.Wall Front(BattleSimulation b) =>
        b
            .Map.DynamicBuildings[0]
            .Walls.First(w =>
                Math.Abs(w.Source.ax - 24.5f) < .01f
                && Math.Abs(w.Source.bx - 24.5f) < .01f
                && w.At(.5f, 1.35f)
                && w.At(.5f, .8f)
            );

    static void Supply(BattleSimulation b)
    {
        foreach (var s in b.Soldiers.Where(s => s.Side == Side.Green && s.Alive))
        {
            s.Rockets = 1;
            s.LauncherKind = s.Id % 2;
            s.ReserveLauncherKind = 1 - s.LauncherKind;
            s.PackRockets = 200;
            s.GrenadeCharges = 200;
            s.GrenadeType = 1;
            s.OtherGrenadeType = 3;
            s.OtherGrenadeCharges = 200;
            s.ThirdGrenadeType = 4;
            s.ThirdGrenadeCharges = 200;
            s.PackGrenades = 200;
            s.PackUnderbarrel = 200;
            s.PackF1 = 200;
            s.LoadedUnderbarrel = 1;
            if (s.Role == Role.Commander || s.Role == Role.Rifleman)
                s.WeaponVariant = 2;
        }
    }

    static void Events()
    {
        foreach (int kind in new[] { 0, 1, 2 })
        {
            var b = Load();
            var p = Front(b).Point(.5f);
            int n = Solid(b),
                r = Roof(b);
            DynamicStructures.Blast(
                b,
                p,
                kind == 2 ? 4.3f
                    : kind == 1 ? 3.3f
                    : 2.5f,
                kind,
                false,
                new V2(1, 0)
            );
            Log(
                new
                {
                    scenario = "wall_blast",
                    kind,
                    wallLost = n - Solid(b),
                    roofLost = r - Roof(b),
                    glass = Glass(b),
                }
            );
        }
        foreach (float radius in new[] { 2.5f, 2.7f, 3.3f, 4.3f })
        {
            var b = Load();
            var k = b.Map.DynamicBuildings[0].Roof.First();
            var p = new V2(((int)(k >> 32) + .5f) / 8, ((int)k + .5f) / 8);
            int n = Roof(b);
            DynamicStructures.Blast(b, p, radius, 0, true, new V2(1, 0));
            Log(
                new
                {
                    scenario = "roof_blast",
                    radius,
                    roofBefore = n,
                    roofAfter = Roof(b),
                }
            );
        }
        {
            var b = Load();
            var w = b.Map.DynamicBuildings[0].Walls.First(w => w.Source.window);
            V2 p = w.Point(.5f),
                d = (w.Point(1) - w.Point(0)).Normalized,
                n = new V2(-d.Y, d.X);
            DynamicStructures.Glass(
                b.Map,
                p - n,
                (w.Source.sill + w.Source.lintel) / 2,
                p + n,
                (w.Source.sill + w.Source.lintel) / 2
            );
            Log(new { scenario = "bullet_window", broken = w.GlassBroken });
        }
        {
            var b = Load();
            var h = b.Map.DynamicBuildings[0];
            var p = new V2(28, 6);
            int within = h.Walls.Count(w => w.Source.window && V2.Distance(w.Point(.5f), p) <= 10);
            DynamicStructures.Blast(b, p, 2.5f, 0, false, new V2(1, 0));
            Log(
                new
                {
                    scenario = "indoor_windows",
                    expected = within,
                    broken = Glass(b),
                }
            );
        }
        foreach (float distance in new[] { .3f, .79f, .81f })
        {
            var b = Load();
            var p = Front(b).Point(.5f);
            var shooter = b.Soldiers[0];
            shooter.Position = p - new V2(7, 0);
            var victim = b.Soldiers.First(s => s.Side == Side.Red && s.Alive);
            victim.Position = p + new V2(distance, 0);
            victim.Health = 100;
            float hp = victim.Health;
            var protectedUnits = DynamicStructures.Shielded(b, p, new V2(1, 0));
            SpecialWeapons.ResolveBlast(b, shooter, p, -1, 0, shooter.Position);
            Log(
                new
                {
                    scenario = "behind_wall",
                    distance,
                    classified = protectedUnits.Contains(victim),
                    damage = hp - victim.Health,
                    concussion = ConcussionEffects.Current(b, victim),
                }
            );
        }
    }

    static void Ai(int launcher, bool contact, bool allyNear)
    {
        var b = Load();
        var p = Front(b).Point(.5f);
        foreach (var unit in b.Soldiers)
        {
            unit.Health = 0;
            unit.Deployed = false;
        }
        var s = b.Soldiers[0];
        s.Health = 100;
        s.Deployed = true;
        s.Role = Role.Grenadier;
        s.Position = p - new V2(7, 0);
        s.Morale = 1;
        s.Suppression = 0;
        s.Rockets = 1;
        s.LauncherKind = launcher;
        s.NextShot = 0;
        s.NextSpecial = 0;
        var enemy = b.Soldiers.First(x => x.Side == Side.Red);
        enemy.Health = 1000;
        enemy.Deployed = true;
        enemy.Position = p + new V2(.3f, 0);
        if (allyNear)
        {
            var a = b.Soldiers[1];
            a.Health = 100;
            a.Deployed = true;
            a.Position = p - new V2(.3f, 0);
        }
        b.Green.Style = CombatStyle.Aggressive;
        int n = Solid(b);
        bool breach = DynamicStructures.CanBreach(
            b.Map,
            s.Position,
            enemy.Position,
            b.Map.LauncherImpact(s.Position, enemy.Position)
        );
        for (int i = 0; i < 240; i++)
        {
            b.Time = i * .05f;
            b.TickNumber = i;
            if (contact)
                s.Contacts[enemy.Id] = new Contact
                {
                    EnemyId = enemy.Id,
                    Position = enemy.Position,
                    Visual = true,
                    Confidence = 1,
                    SeenAt = b.Time,
                    FireSeenAt = b.Time,
                };
            SpecialWeapons.TryLaunch(b, s);
            ArcedOrdnance.Update(b);
            if (b.Stats.RocketsFired > 0 && b.Projectiles.Count == 0)
                break;
        }
        Log(
            new
            {
                scenario = "controlled_ai",
                launcher,
                contact,
                allyNear,
                breach,
                launched = b.Stats.RocketsFired,
                wallLost = n - Solid(b),
                reason = s.Reason,
                time = b.Time,
            }
        );
    }

    static void Battle(int seed)
    {
        var b = Load(seed);
        Supply(b);
        int initial = Solid(b);
        var ids = new HashSet<ArcProjectile>();
        int[] launched = new int[5];
        float next = 0;
        var sw = Stopwatch.StartNew();
        for (int i = 0; i < 2400 && b.Outcome == 0; i++)
        {
            foreach (var s in b.Soldiers.Where(s => s.Side == Side.Green && s.Alive))
            {
                if (s.Rockets == 0 && b.Time > s.NextSpecial)
                    s.Rockets = 1;
                if (s.Underbarrel && s.LoadedUnderbarrel == 0 && b.Time > s.NextSpecial)
                    s.LoadedUnderbarrel = 1;
            }
            b.Step();
            foreach (var p in b.Projectiles)
                if (ids.Add(p))
                    launched[p.Kind]++;
            if (b.Time >= next)
            {
                next += 30;
                Console.WriteLine($"progress seed={seed} t={b.Time:F1} rockets={b.Stats.RocketsFired}");
            }
        }
        Log(
            new
            {
                scenario = "first_map_battle",
                seed,
                time = b.Time,
                result = b.Outcome.ToString(),
                rockets = b.Stats.RocketsFired,
                projectilesObserved = launched,
                wallLost = initial - Solid(b),
                roofRemaining = Roof(b),
                glass = Glass(b),
                shots = b.Stats.Shots,
                green = b.Alive(Side.Green),
                red = b.Alive(Side.Red),
                elapsedMs = sw.ElapsedMilliseconds,
            }
        );
    }

    static void Demolition()
    {
        var b = Load();
        var walls = b.Map.DynamicBuildings[0].Walls;
        int n = Solid(b),
            r = Roof(b),
            roofGone = 0;
        var milestones = new HashSet<int> { 1, 2, 5, 10, 20, 50, 70, 140, 210, 350, 700, 1000 };
        var sw = Stopwatch.StartNew();
        for (int shot = 1; shot <= 1000; shot++)
        {
            b.TickNumber = shot;
            var p = walls[(shot - 1) % walls.Count].Point(.5f);
            DynamicStructures.Blast(
                b,
                p,
                4.3f,
                2,
                false,
                new V2(1, 0),
                DynamicStructures.SampleWallHeight(b.Random, walls[(shot - 1) % walls.Count].Source.height)
            );
            b.Map.BrokenCovers.Clear();
            if (Roof(b) == 0 && roofGone == 0)
                roofGone = shot;
            if (milestones.Contains(shot) || Solid(b) == 0)
                Log(
                    new
                    {
                        scenario = "rshg_sweep",
                        shot,
                        wallBefore = n,
                        wallRemaining = Solid(b),
                        roofBefore = r,
                        roofRemaining = Roof(b),
                        roofGoneAt = roofGone,
                        tall = Tall(b),
                        elapsedMs = sw.ElapsedMilliseconds,
                    }
                );
            if (Solid(b) == 0)
                break;
        }
        int baseLeft = 0;
        foreach (var w in walls)
            for (int x = 0; x < w.NX; x++)
                if (w.Solid[x])
                    baseLeft++;
        Log(new { scenario = "foundation_remaining", baseLeft });
    }

    static void RoofSamples()
    {
        foreach (var p in new[] { new V2(26, 4), new V2(28, 6), new V2(30, 8) })
        {
            var b = Load();
            int n = Roof(b);
            DynamicStructures.Blast(b, p, 4.3f, 2, false, new V2(1, 0), .8f);
            Log(
                new
                {
                    scenario = "interior_rshg",
                    x = p.X,
                    y = p.Y,
                    before = n,
                    after = Roof(b),
                    wallRemaining = Solid(b),
                }
            );
        }
    }

    static void HeightDistribution()
    {
        var rng = new Rng(151);
        int[] bins = new int[10];
        float min = 10,
            max = -1;
        for (int i = 0; i < 100000; i++)
        {
            float z = DynamicStructures.SampleWallHeight(rng, 2.8f);
            bins[Math.Min(9, (int)(z / 2.8f * 10))]++;
            min = Math.Min(min, z);
            max = Math.Max(max, z);
        }
        Log(
            new
            {
                scenario = "height_distribution",
                samples = 100000,
                bins,
                min,
                max,
            }
        );
    }

    static void PhysicalDemolition(int seed)
    {
        var b = Load(seed);
        foreach (var unit in b.Soldiers)
        {
            unit.Health = 0;
            unit.Deployed = false;
        }
        var s = b.Soldiers[0];
        s.Health = 100000;
        s.Deployed = true;
        s.Role = Role.Grenadier;
        s.LauncherKind = 1;
        var house = b.Map.DynamicBuildings[0];
        int before = Solid(b),
            shots = 0,
            roofGone = 0,
            deadHouse = 0;
        var milestones = new HashSet<int> { 1, 2, 5, 10, 20, 30, 50, 70, 100, 150, 200, 300 };
        var sw = Stopwatch.StartNew();
        for (int attempt = 0; attempt < 2100 && shots < 300 && Solid(b) > 0; attempt++)
        {
            var w = house.Walls[attempt % house.Walls.Count];
            if (!w.Solid.Any(v => v))
                continue;
            V2 target = w.Point(.5f);
            V2 origin = new V2();
            bool found = false;
            for (int j = 0; j < 32; j++)
            {
                double angle = 2 * Math.PI * j / 32;
                var q = target + new V2((float)Math.Cos(angle) * 7, (float)Math.Sin(angle) * 7);
                if (
                    !b.Map.Inside((int)Math.Floor(q.X), (int)Math.Floor(q.Y))
                    || house.Contains(q)
                    || !b.Map.Walkable((int)q.X, (int)q.Y)
                )
                    continue;
                if (V2.Distance(b.Map.LauncherImpact(q, target), target) > .3f)
                    continue;
                origin = q;
                found = true;
                break;
            }
            if (!found)
                continue;
            s.Position = origin;
            s.Rockets = 1;
            SpecialWeapons.LaunchProjectile(b, s, target);
            var rocket = b.Projectiles.Last();
            shots++;
            for (int t = 0; t < 80 && b.Projectiles.Count > 0; t++)
            {
                b.Time += .05f;
                b.TickNumber++;
                ArcedOrdnance.Update(b);
            }
            if (b.Projectiles.Count > 0)
                throw new Exception("Projectile did not resolve");
            b.Map.BrokenCovers.Clear();
            b.Blasts.Clear();
            if (Roof(b) == 0 && roofGone == 0)
                roofGone = shots;
            if (Tall(b) == 0 && Roof(b) == 0 && deadHouse == 0)
                deadHouse = shots;
            if (milestones.Contains(shots) || Solid(b) == 0)
                Log(
                    new
                    {
                        scenario = "physical_rshg_demolition",
                        seed,
                        shots,
                        wallBefore = before,
                        wallRemaining = Solid(b),
                        tall = Tall(b),
                        roofRemaining = Roof(b),
                        roofGoneAt = roofGone,
                        houseBelowSillAt = deadHouse,
                        lastImpactHeight = rocket.Height,
                        elapsedMs = sw.ElapsedMilliseconds,
                    }
                );
        }
        Log(
            new
            {
                scenario = "physical_demolition_final",
                seed,
                shots,
                wallBefore = before,
                wallRemaining = Solid(b),
                tall = Tall(b),
                roofRemaining = Roof(b),
                roofGoneAt = roofGone,
                houseBelowSillAt = deadHouse,
            }
        );
    }

    static void DamageContract()
    {
        foreach (int kind in new[] { 1, 2 })
        {
            var b = Load();
            var p = Front(b).Point(.5f);
            var shooter = b.Soldiers[0];
            shooter.Position = p - new V2(7, 0);
            var victim = b.Soldiers.First(s => s.Side == Side.Red && s.Alive);
            victim.Position = p + new V2(.3f, 0);
            victim.Health = 100;
            var list = DynamicStructures.Shielded(b, p, new V2(1, 0));
            DynamicStructures.Blast(b, p, kind == 2 ? 4.3f : 3.3f, kind, false, new V2(1, 0));
            b.Random.Reseed(12345);
            var rng = new Rng(12345);
            float d = V2.Distance(victim.Position, p),
                raw = kind == 2
                    ? 65 - 15 * Util.Clamp(d / 4.3f, 0, 1)
                    : rng.Range(34.15f, 54.4f)
                        * (1 - d / 4.3f)
                        * (1 - CombatTraining.Cover(b, victim, victim.Position, p) * .55f);
            float expected = .7f * raw * BodyArmor.DamageMultiplier(victim.ArmorLevel);
            DynamicStructures.BehindDamage(b, shooter, p, list, kind, new HashSet<int>());
            float actual = 100 - victim.Health;
            if (Math.Abs(actual - expected) > .0001f)
                throw new Exception("0.7 damage formula mismatch");
            float hp = victim.Health;
            DynamicStructures.BehindDamage(b, shooter, p, list, kind, new HashSet<int> { victim.Id });
            if (victim.Health != hp)
                throw new Exception("Duplicate blast damage");
            Log(
                new
                {
                    scenario = "damage_contract",
                    kind,
                    expected,
                    actual,
                    duplicatePrevented = true,
                }
            );
        }
    }

    static void Chips()
    {
        foreach (float distance in new[] { 0f, .1f, .17f, .5f })
        foreach (float height in new[] { 0f, 1.35f, 2.7f })
        {
            var b = Load();
            var house = b.Map.DynamicBuildings[0];
            var w = Front(b);
            house.Walls.Clear();
            house.Walls.Add(w);
            house.Roof.Clear();
            for (int i = 0; i < w.Solid.Length; i++)
                w.Solid[i] = true;
            w.Source.window = false;
            var p = w.Point(.5f) + new V2(-distance, 0);
            int before = Solid(b);
            DynamicStructures.Blast(b, p, 2.5f, 0, false, new V2(1, 0), height);
            int lost = before - Solid(b);
            if (distance >= .17f && lost != 0)
                throw new Exception("Distant grenade damaged wall");
            if (distance <= .1f && (lost <= 0 || lost > 100))
                throw new Exception("Contact chip incorrect size");
            Log(
                new
                {
                    scenario = "small_chip",
                    distance,
                    height,
                    lost,
                }
            );
        }
    }

    static void Main(string[] args)
    {
        string mode = args.Length > 0 ? args[0] : "events";
        try
        {
            if (mode == "chips")
                Chips();
            else if (mode == "damage")
                DamageContract();
            else if (mode == "heights")
                HeightDistribution();
            else if (mode == "physical")
                for (int seed = 151; seed < 156; seed++)
                    PhysicalDemolition(seed);
            else if (mode == "roof")
                RoofSamples();
            else if (mode == "events")
                Events();
            else if (mode == "ai")
            {
                Ai(0, true, false);
                Ai(1, true, false);
                Ai(0, false, false);
                Ai(0, true, true);
            }
            else if (mode == "battle")
                for (int i = 0; i < 20; i++)
                    Battle(15100 + i);
            else if (mode == "demolition")
                Demolition();
        }
        finally
        {
            File.WriteAllText(
                Path.Combine(AppContext.BaseDirectory, mode + "-results.json"),
                JsonConvert.SerializeObject(results, Formatting.Indented)
            );
        }
    }
}
