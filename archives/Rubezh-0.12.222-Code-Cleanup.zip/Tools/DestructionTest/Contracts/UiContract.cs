// Compile-time API contract only. This is NOT a Unity runtime, renderer or layout test.
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace UnityEngine {public enum KeyCode{Escape} public enum ScaleMode{ScaleToFit,ScaleAndCrop,StretchToFill} }
namespace UnityEngine.UIElements {
 public enum PanelScaleMode{ConstantPixelSize}public enum Position{Absolute}public enum DisplayStyle{None,Flex}public enum PickingMode{Ignore}public enum ScrollViewMode{Horizontal,Vertical,VerticalAndHorizontal}public enum ScrollerVisibility{Hidden,Auto}
 public struct FontDefinition{public static FontDefinition FromFont(Font f)=>new FontDefinition();public static FontDefinition FromSDFFont(UnityEngine.TextCore.Text.FontAsset f)=>new FontDefinition();}
 public struct Length{public static Length Percent(float v)=>new Length();public static implicit operator Length(float v)=>new Length();}
 public struct Angle{public Angle(float x){}}public struct Rotate{public Rotate(Angle x){}}public struct Scale{public Scale(Vector3 v){}}public struct Translate{public Translate(Length x,Length y){}}
 public struct Background {public Texture2D texture;} public struct StyleBackground {public Background value; public StyleBackground(Texture2D t){value=new Background{texture=t};}} public class Style {public StyleBackground backgroundImage; public Color backgroundColor;public Position position;public Length left,top,right,bottom,width,height,maxWidth,maxHeight,marginRight,marginBottom;public float flexGrow,flexShrink,opacity,fontSize;public DisplayStyle display;public Rotate rotate;public Scale scale;public Translate translate;public Font unityFont;public FontDefinition unityFontDefinition;}
 public class ResolvedStyle{public DisplayStyle display;public float width,height;}
 public class EventBase{} public class GeometryChangedEvent:EventBase{public Rect newRect;}public class KeyDownEvent:EventBase{public KeyCode keyCode;public void StopPropagation(){}} public class ChangeEvent<T>:EventBase{public T newValue;}
 public interface IVisualElementScheduledItem{void Pause();IVisualElementScheduledItem Every(long ms);}
 class Scheduled:IVisualElementScheduledItem{public void Pause(){}public IVisualElementScheduledItem Every(long ms)=>this;}
 public class Scheduler{public IVisualElementScheduledItem Execute(Action a)=>new Scheduled();}
 public class QueryResult<T>{public void ForEach(Action<T> action){}} public class VisualElement:IEnumerable<VisualElement>{ public QueryResult<T> Query<T>(string className=null) where T:VisualElement => new QueryResult<T>();readonly List<VisualElement> children=new List<VisualElement>();readonly HashSet<string> classes=new HashSet<string>();VisualElement parent;public bool enabledInHierarchy=true;public Rect worldBound;public string name,tooltip;public PickingMode pickingMode;public Style style=new Style();public ResolvedStyle resolvedStyle=new ResolvedStyle();public Scheduler schedule=new Scheduler();public Action<MeshGenerationContext> generateVisualContent;public List<StyleSheet> styleSheets=new List<StyleSheet>();public int childCount=>children.Count;public bool ClassListContains(string s)=>classes.Contains(s);public VisualElement this[int n]=>children[n];public virtual void Add(VisualElement v){v.RemoveFromHierarchy();children.Add(v);v.parent=this;}public void Insert(int n,VisualElement v){v.RemoveFromHierarchy();children.Insert(n,v);v.parent=this;}public void Clear(){foreach(var c in children)c.parent=null;children.Clear();}public IEnumerable<string> GetClasses()=>classes;public void AddToClassList(string s)=>classes.Add(s);public void RemoveFromClassList(string s)=>classes.Remove(s);public void EnableInClassList(string s,bool v){if(v)classes.Add(s);else classes.Remove(s);}public void SetEnabled(bool v){enabledInHierarchy=v;}public void RemoveFromHierarchy(){if(parent!=null)parent.children.Remove(this);parent=null;}public void BringToFront(){}public void Focus(){}public int IndexOf(VisualElement v)=>children.IndexOf(v);public IEnumerable<VisualElement> Children()=>children;public IEnumerator<VisualElement> GetEnumerator()=>children.GetEnumerator();IEnumerator IEnumerable.GetEnumerator()=>GetEnumerator();public void RegisterCallback<T>(Action<T> a)where T:EventBase{} }

 public class Label:VisualElement{public string text;public bool enableRichText;public Label(){}public Label(string s){text=s;}}
 public class Button:VisualElement{public string text;public Action action;public Button(Action a){action=a;}public void Click(){if(enabledInHierarchy)action();}}
 public class Image:VisualElement{public Color tintColor;public Rect uv;public Texture image;public UnityEngine.ScaleMode scaleMode;}
 public class ScrollView:VisualElement{public VisualElement contentViewport=new VisualElement();public VisualElement contentContainer=new VisualElement();public Vector2 scrollOffset;public ScrollerVisibility horizontalScrollerVisibility,verticalScrollerVisibility;public ScrollView(ScrollViewMode m){base.Add(contentContainer);}public override void Add(VisualElement v)=>contentContainer.Add(v); }
 public class DropdownField:VisualElement{public DropdownField(string label,List<string> values,int index){}public void RegisterValueChangedCallback(Action<ChangeEvent<string>> a){} }
 public class IntegerField:VisualElement{public int value;public IntegerField(string label){} }
 public class Toggle:VisualElement{public bool value;public Toggle(string label){}public void RegisterValueChangedCallback(Action<ChangeEvent<bool>> a){} }
 public class SliderInt:VisualElement{public int value;public SliderInt(int min,int max){}public void RegisterValueChangedCallback(Action<ChangeEvent<int>> a){} }
 public class TextField:VisualElement{public int maxLength;public string value;public bool multiline;}
 public class PanelSettings:ScriptableObject{public RenderTexture targetTexture;public PanelScaleMode scaleMode;public int sortingOrder;public float scale;public ThemeStyleSheet themeStyleSheet;}
 public class StyleSheet:UnityEngine.Object{}public class ThemeStyleSheet:StyleSheet{}
 public class UIDocument:MonoBehaviour{public PanelSettings panelSettings;public VisualElement rootVisualElement=new VisualElement();}
 public class MeshGenerationContext{public Painter2D painter2D=new Painter2D();}
 public class Painter2D{public Color strokeColor;public float lineWidth;public void BeginPath(){}public void MoveTo(Vector2 p){}public void LineTo(Vector2 p){}public void Stroke(){} }
}

namespace UnityEngine.TextCore.LowLevel{public enum GlyphRenderMode{SDFAA}}
namespace UnityEngine.TextCore.Text {public enum AtlasPopulationMode{Dynamic}public class FontAsset:UnityEngine.Object{public List<FontAsset> fallbackFontAssetTable;public Texture2D[] atlasTextures=new Texture2D[0];public Material material;public static FontAsset CreateFontAsset(Font f,int s,int p,UnityEngine.TextCore.LowLevel.GlyphRenderMode r,int w,int h,AtlasPopulationMode m,bool multi)=>new FontAsset();}}
